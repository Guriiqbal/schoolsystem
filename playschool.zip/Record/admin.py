from django.contrib import admin
from .models.students import Students
from .models.courses import Classes
from .models.staff import Staff
from .models.staff_category import Staff_Category

class AdminStudent(admin.ModelAdmin):
    list_display = ['Name','DOB','gender','Father_name','Mother_name','Contact','Class','Address','image']


class AdminCourse(admin.ModelAdmin):
    list_display = ['course_name','price','Time_duration','description']

class AdminStaff(admin.ModelAdmin):
    list_display = ['Staff_name','DOB','gender','Staff_Category','Contact','Email','Qualification','image']


class AdminStaffCategory(admin.ModelAdmin):
    list_display = ['Category']

admin.site.register(Students,AdminStudent)
admin.site.register(Classes,AdminCourse)

admin.site.register(Staff,AdminStaff)
admin.site.register(Staff_Category,AdminStaffCategory)



