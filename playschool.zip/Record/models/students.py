from django.db import models
from .courses import Classes

class Students(models.Model):
    Name = models.CharField(max_length=30)
    Father_name = models.CharField(max_length=30)
    Mother_name = models.CharField(max_length=30)
    DOB = models.CharField(max_length=30)
    gender=models.CharField(max_length=20)
    Class=models.CharField(max_length=30)
    Contact=models.IntegerField(default=0)
    Address = models.CharField(max_length=500,default="Address Not Found")
    image=models.ImageField(upload_to='students/')

    def register(self):
        self.save()

    def IsExists(self):
        if Students.objects.filter(Email=self.Email, Contact=self.Contact):
            return True
        return False