from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')


def classes(request):
    return render(request, 'classes.html')


def contact(request):
    return render(request, 'contact.html')

def Registration(request):
    return render(request, 'registration.html')

def admissions(request):
    return render(request, 'admissions.html')
